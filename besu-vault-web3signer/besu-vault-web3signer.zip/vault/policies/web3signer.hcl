path "web3signer/data/accounts/sender" {
  capabilities = ["read"]
}

path "web3signer/metadata/accounts/sender" {
  capabilities = ["read"]
}

