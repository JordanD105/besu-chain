#!/usr/bin/env sh
set -eu

if [ -z "${VAULT_TOKEN:-}" ]; then
  echo "Set VAULT_TOKEN to an initialized, unsealed Vault administrator token." >&2
  exit 1
fi

if [ -z "${SENDER_PRIVATE_KEY:-}" ]; then
  echo "Set SENDER_PRIVATE_KEY to the 32-byte Ethereum private key without 0x." >&2
  exit 1
fi

case "$SENDER_PRIVATE_KEY" in
  *[!0-9a-fA-F]*|'')
    echo "SENDER_PRIVATE_KEY must contain exactly 64 hexadecimal characters." >&2
    exit 1
    ;;
esac

if [ "${#SENDER_PRIVATE_KEY}" -ne 64 ]; then
  echo "SENDER_PRIVATE_KEY must contain exactly 64 hexadecimal characters." >&2
  exit 1
fi

mkdir -p .secrets web3signer/keys
chmod 700 .secrets web3signer/keys

docker compose exec -T \
  -e VAULT_TOKEN="$VAULT_TOKEN" \
  vault vault secrets enable -path=web3signer -version=2 kv 2>/dev/null || true

docker compose exec -T \
  -e VAULT_TOKEN="$VAULT_TOKEN" \
  vault vault policy write web3signer /vault/policies/web3signer.hcl

docker compose exec -T \
  -e VAULT_TOKEN="$VAULT_TOKEN" \
  -e SENDER_PRIVATE_KEY="$SENDER_PRIVATE_KEY" \
  vault sh -c 'vault kv put web3signer/accounts/sender privateKey="$SENDER_PRIVATE_KEY" >/dev/null'

SIGNER_TOKEN="$(docker compose exec -T \
  -e VAULT_TOKEN="$VAULT_TOKEN" \
  vault vault token create \
    -policy=web3signer \
    -display-name=web3signer \
    -ttl=720h \
    -renewable=true \
    -field=token | tr -d '\r')"

umask 077
printf '%s\n' "$SIGNER_TOKEN" > .secrets/web3signer-token

sed "s|__VAULT_TOKEN__|$SIGNER_TOKEN|g" \
  web3signer/sender.yaml.template > web3signer/keys/sender.yaml

chmod 600 .secrets/web3signer-token web3signer/keys/sender.yaml
unset SENDER_PRIVATE_KEY SIGNER_TOKEN

echo "Vault key and Web3Signer policy were provisioned."
echo "Start the signer with: docker compose up -d web3signer"

